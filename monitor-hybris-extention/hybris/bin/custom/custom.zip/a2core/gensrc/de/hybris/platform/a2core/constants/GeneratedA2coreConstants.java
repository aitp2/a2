/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Dec 20, 2017 10:58:40 AM                    ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2016 SAP SE
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of SAP
 * Hybris ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with SAP Hybris.
 *  
 */
package de.hybris.platform.a2core.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedA2coreConstants
{
	public static final String EXTENSIONNAME = "a2core";
	public static class Enumerations
	{
		public static class OrderStatus
		{
			public static final String SAPBACK = "SAPBACK".intern();
			public static final String PAY = "PAY".intern();
			public static final String PAYFAIL = "PAYFAIL".intern();
		}
	}
	
	protected GeneratedA2coreConstants()
	{
		// private constructor
	}
	
	
}
